/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
/* USER CODE END Includes */


/* USER CODE BEGIN PD */

/* BMP280 Register Map */
#define BMP280_REG_DIG_T1       0x88U
#define BMP280_REG_DIG_T2       0x8AU
#define BMP280_REG_DIG_T3       0x8CU

#define BMP280_REG_DIG_P1       0x8EU
#define BMP280_REG_DIG_P2       0x90U
#define BMP280_REG_DIG_P3       0x92U
#define BMP280_REG_DIG_P4       0x94U
#define BMP280_REG_DIG_P5       0x96U
#define BMP280_REG_DIG_P6       0x98U
#define BMP280_REG_DIG_P7       0x9AU
#define BMP280_REG_DIG_P8       0x9CU
#define BMP280_REG_DIG_P9       0x9EU

#define BMP280_REG_CHIP_ID      0xD0U
#define BMP280_REG_RESET        0xE0U
#define BMP280_REG_STATUS       0xF3U
#define BMP280_REG_CTRL_MEAS    0xF4U
#define BMP280_REG_CONFIG       0xF5U
#define BMP280_REG_BURST_START  0xF7U

#define BMP280_CHIP_ID_PRIMARY  0x58U
#define BMP280_CHIP_ID_ALT1     0x57U
#define BMP280_CHIP_ID_ALT2     0x56U

#define BMP280_SOFT_RESET_CMD   0xB6U

/* USER CODE END PD */


/* USER CODE BEGIN PTD */

typedef struct
{
    uint16_t dig_T1;
    int16_t  dig_T2;
    int16_t  dig_T3;

    uint16_t dig_P1;
    int16_t  dig_P2;
    int16_t  dig_P3;
    int16_t  dig_P4;
    int16_t  dig_P5;
    int16_t  dig_P6;
    int16_t  dig_P7;
    int16_t  dig_P8;
    int16_t  dig_P9;

} BMP280_Calib_t;

/* USER CODE END PTD */

/* Private variables ---------------------------------------------------------*/
SPI_HandleTypeDef hspi1;

TIM_HandleTypeDef htim6;

UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */

static BMP280_Calib_t calib;

static int32_t t_fine;

volatile int32_t  g_comp_T = 0;
volatile uint32_t g_comp_P = 0;
volatile uint32_t g_tick   = 0;




/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_SPI1_Init(void);
static void MX_TIM6_Init(void);
static void MX_USART2_UART_Init(void);

/* USER CODE BEGIN PFP */

/* BMP280 low-level functions */
void BMP280_WriteReg(uint8_t reg, uint8_t value);
uint8_t BMP280_ReadReg(uint8_t reg);
void BMP280_BurstRead(uint8_t start_reg,
                      uint8_t *buf,
                      uint8_t length);

/* Calibration */
void BMP280_ReadCalibration(void);

/* Compensation formulas */
int32_t BMP280_Compensate_T(int32_t adc_T);
uint32_t BMP280_Compensate_P(int32_t adc_P);

/* Helper */
void SampleAndCompensate(void);

/* Sensor initialization */
uint8_t BMP280_Init(void);


/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* -------------------- BMP280 SPI Functions -------------------- */

void BMP280_WriteReg(uint8_t reg, uint8_t value)
{
    uint8_t tx[2];

    tx[0] = reg & 0x7F;      // Write operation
    tx[1] = value;

    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, GPIO_PIN_RESET);

    HAL_SPI_Transmit(&hspi1, tx, 2, HAL_MAX_DELAY);

    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, GPIO_PIN_SET);
}


uint8_t BMP280_ReadReg(uint8_t reg)
{
    uint8_t tx = reg | 0x80;     // Read operation
    uint8_t rx;

    uint8_t dummy = 0xFF;

    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, GPIO_PIN_RESET);

    HAL_SPI_Transmit(&hspi1, &tx, 1, HAL_MAX_DELAY);

    HAL_SPI_TransmitReceive(&hspi1,
                             &dummy,
                             &rx,
                             1,
                             HAL_MAX_DELAY);

    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, GPIO_PIN_SET);

    return rx;
}


void BMP280_BurstRead(uint8_t start_reg,
                      uint8_t *buf,
                      uint8_t length)
{
    uint8_t tx = start_reg | 0x80;

    uint8_t dummy[24];

    for(uint8_t i=0;i<length;i++)
    {
        dummy[i] = 0xFF;
    }

    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, GPIO_PIN_RESET);

    HAL_SPI_Transmit(&hspi1, &tx, 1, HAL_MAX_DELAY);

    HAL_SPI_TransmitReceive(&hspi1,
                             dummy,
                             buf,
                             length,
                             HAL_MAX_DELAY);

    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, GPIO_PIN_SET);
}


/* -------------------- Calibration -------------------- */

void BMP280_ReadCalibration(void)
{
    uint8_t calib_buf[24];

    BMP280_BurstRead(BMP280_REG_DIG_T1, calib_buf, 24);

    calib.dig_T1 = (uint16_t)(calib_buf[1] << 8 | calib_buf[0]);
    calib.dig_T2 = (int16_t)(calib_buf[3] << 8 | calib_buf[2]);
    calib.dig_T3 = (int16_t)(calib_buf[5] << 8 | calib_buf[4]);

    calib.dig_P1 = (uint16_t)(calib_buf[7] << 8 | calib_buf[6]);
    calib.dig_P2 = (int16_t)(calib_buf[9] << 8 | calib_buf[8]);
    calib.dig_P3 = (int16_t)(calib_buf[11] << 8 | calib_buf[10]);
    calib.dig_P4 = (int16_t)(calib_buf[13] << 8 | calib_buf[12]);
    calib.dig_P5 = (int16_t)(calib_buf[15] << 8 | calib_buf[14]);
    calib.dig_P6 = (int16_t)(calib_buf[17] << 8 | calib_buf[16]);
    calib.dig_P7 = (int16_t)(calib_buf[19] << 8 | calib_buf[18]);
    calib.dig_P8 = (int16_t)(calib_buf[21] << 8 | calib_buf[20]);
    calib.dig_P9 = (int16_t)(calib_buf[23] << 8 | calib_buf[22]);
}


/* -------------------- Temperature Compensation -------------------- */

int32_t BMP280_Compensate_T(int32_t adc_T)
{
    int32_t var1, var2, T;

    var1 = ((((adc_T >> 3) - ((int32_t)calib.dig_T1 << 1))) *
            ((int32_t)calib.dig_T2)) >> 11;

    var2 = (((((adc_T >> 4) - ((int32_t)calib.dig_T1)) *
            ((adc_T >> 4) - ((int32_t)calib.dig_T1))) >> 12) *
            ((int32_t)calib.dig_T3)) >> 14;

    t_fine = var1 + var2;

    T = (t_fine * 5 + 128) >> 8;

    return T;
}


/* -------------------- Pressure Compensation -------------------- */

uint32_t BMP280_Compensate_P(int32_t adc_P)
{
    int64_t var1, var2, p;

    var1 = ((int64_t)t_fine) - 128000;
    var2 = var1 * var1 * (int64_t)calib.dig_P6;
    var2 = var2 + ((var1 * (int64_t)calib.dig_P5) << 17);
    var2 = var2 + (((int64_t)calib.dig_P4) << 35);

    var1 = ((var1 * var1 * (int64_t)calib.dig_P3) >> 8)
         + ((var1 * (int64_t)calib.dig_P2) << 12);

    var1 = ((((int64_t)1) << 47) + var1)
         * ((int64_t)calib.dig_P1) >> 33;

    if (var1 == 0)
        return 0;

    p = 1048576 - adc_P;
    p = (((p << 31) - var2) * 3125) / var1;

    var1 = (((int64_t)calib.dig_P9) * (p >> 13) * (p >> 13)) >> 25;

    var2 = (((int64_t)calib.dig_P8) * p) >> 19;

    p = ((p + var1 + var2) >> 8)
      + (((int64_t)calib.dig_P7) << 4);

    return (uint32_t)p;
}


/* -------------------- Sample Sensor -------------------- */

void SampleAndCompensate(void)
{
    uint8_t data[6];

    int32_t adc_P;
    int32_t adc_T;

    BMP280_BurstRead(BMP280_REG_BURST_START, data, 6);

    adc_P = ((int32_t)data[0] << 12)
          | ((int32_t)data[1] << 4)
          | ((int32_t)data[2] >> 4);

    adc_T = ((int32_t)data[3] << 12)
          | ((int32_t)data[4] << 4)
          | ((int32_t)data[5] >> 4);

    g_comp_T = BMP280_Compensate_T(adc_T);

    g_comp_P = BMP280_Compensate_P(adc_P);
}


/* -------------------- BMP280 Initialization -------------------- */

uint8_t BMP280_Init(void)
{
    uint8_t chip_id;

    BMP280_WriteReg(BMP280_REG_RESET,
                    BMP280_SOFT_RESET_CMD);

    HAL_Delay(10);

    /* Wait until NVM calibration copy finishes */
    while(BMP280_ReadReg(BMP280_REG_STATUS) & 0x01)
    {
    }

    HAL_Delay(10);

    chip_id = BMP280_ReadReg(BMP280_REG_CHIP_ID);

    if ((chip_id != BMP280_CHIP_ID_PRIMARY) &&
        (chip_id != BMP280_CHIP_ID_ALT1) &&
        (chip_id != BMP280_CHIP_ID_ALT2))
    {
        return 0;
    }

    BMP280_ReadCalibration();

    /* CONFIG = 0x10 */
    BMP280_WriteReg(BMP280_REG_CONFIG, 0x10);

    /* CTRL_MEAS = 0x57 */
    BMP280_WriteReg(BMP280_REG_CTRL_MEAS, 0x57);

    HAL_Delay(10);

    return 1;
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_SPI1_Init();
  MX_TIM6_Init();
  MX_USART2_UART_Init();
  /* USER CODE BEGIN 2 */
  char msg[256];

  HAL_UART_Transmit(&huart2,
                    (uint8_t*)"Before sprintf\r\n",
                    15,
                    HAL_MAX_DELAY);

  sprintf(msg,
           "\r\n========================================\r\n"
           " CSE 2206 - Assignment 3 Part A\r\n"
           " BMP280 via SPI1 HAL (STM32F446RE)\r\n"
           "========================================\r\n");

  HAL_UART_Transmit(&huart2,
                    (uint8_t*)msg,
                    strlen(msg),
                    HAL_MAX_DELAY);

  HAL_Delay(100);

  if (!BMP280_Init())
  {
      sprintf(msg,
              "ERROR: BMP280 not detected! Halting.\r\n");

      HAL_UART_Transmit(&huart2,
                        (uint8_t*)msg,
                        strlen(msg),
                        HAL_MAX_DELAY);

      while (1);
  }

  sprintf(msg,
          "BMP280 detected successfully.\r\n");

  HAL_UART_Transmit(&huart2,
                    (uint8_t*)msg,
                    strlen(msg),
                    HAL_MAX_DELAY);

  /* Take first sample */
  SampleAndCompensate();

  /* Start TIM6 interrupt */
  HAL_TIM_Base_Start_IT(&htim6);


  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_BYPASS;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 4;
  RCC_OscInitStruct.PLL.PLLN = 180;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 2;
  RCC_OscInitStruct.PLL.PLLR = 2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Activate the Over-Drive mode
  */
  if (HAL_PWREx_EnableOverDrive() != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief SPI1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI1_Init(void)
{

  /* USER CODE BEGIN SPI1_Init 0 */

  /* USER CODE END SPI1_Init 0 */

  /* USER CODE BEGIN SPI1_Init 1 */

  /* USER CODE END SPI1_Init 1 */
  /* SPI1 parameter configuration*/
  hspi1.Instance = SPI1;
  hspi1.Init.Mode = SPI_MODE_MASTER;
  hspi1.Init.Direction = SPI_DIRECTION_2LINES;
  hspi1.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi1.Init.CLKPolarity = SPI_POLARITY_HIGH;
  hspi1.Init.CLKPhase = SPI_PHASE_2EDGE;
  hspi1.Init.NSS = SPI_NSS_SOFT;
  hspi1.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_256;
  hspi1.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi1.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi1.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi1.Init.CRCPolynomial = 10;
  if (HAL_SPI_Init(&hspi1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI1_Init 2 */

  /* USER CODE END SPI1_Init 2 */

}

/**
  * @brief TIM6 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM6_Init(void)
{

  /* USER CODE BEGIN TIM6_Init 0 */

  /* USER CODE END TIM6_Init 0 */

  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM6_Init 1 */

  /* USER CODE END TIM6_Init 1 */
  htim6.Instance = TIM6;
  htim6.Init.Prescaler = 8999;
  htim6.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim6.Init.Period = 9999;
  htim6.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim6) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim6, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM6_Init 2 */

  /* USER CODE END TIM6_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_6, GPIO_PIN_SET);

  /*Configure GPIO pin : B1_Pin */
  GPIO_InitStruct.Pin = B1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : PB6 */
  GPIO_InitStruct.Pin = GPIO_PIN_6;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
    if (htim->Instance == TIM6)
    {
        g_tick++;

        SampleAndCompensate();

        int32_t tc_w = g_comp_T / 100;
        int32_t tc_f = g_comp_T % 100;
        if (tc_f < 0)
            tc_f = -tc_f;

        int32_t tf_s = g_comp_T * 9 / 5 + 3200;

        int32_t tf_w = tf_s / 100;
        int32_t tf_f = tf_s % 100;
        if (tf_f < 0)
            tf_f = -tf_f;

        uint32_t pp  = g_comp_P / 256U;
        uint32_t phw = pp / 100U;
        uint32_t phf = pp % 100U;

        char msg[256];

        sprintf(msg,
                "========================================\r\n"
                " BMP280 via SPI -- CSE 2206 Lab A\r\n"
                "========================================\r\n"
                "Temperature : %ld.%02ld C / %ld.%02ld F\r\n"
                "Pressure    : %lu.%02lu hPa\r\n"
                "Humidity    : N/A (BMP280)\r\n"
                "----------------------------------------\r\n",
                (long)tc_w,
                (long)tc_f,
                (long)tf_w,
                (long)tf_f,
                (unsigned long)phw,
                (unsigned long)phf);

        HAL_UART_Transmit(&huart2,
                          (uint8_t*)msg,
                          strlen(msg),
                          HAL_MAX_DELAY);

    }
}


/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

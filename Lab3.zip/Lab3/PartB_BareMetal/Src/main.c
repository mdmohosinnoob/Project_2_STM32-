/*
 * ============================================================
 * CSE 2206 — Microcontroller & Embedded System Lab
 * Assignment 3, Part B: BMP280 Sensor Interface — BARE-METAL (I2C)
 * Platform  : STM32F446RE Nucleo-64
 * Clock     : SYSCLK = 180 MHz (HSE PLL), APB1 = 45 MHz
 * Pin Mapping:
 * PB8  → I2C1_SCL   (AF4, Open-Drain, Pull-Up)
 * PB9  → I2C1_SDA   (AF4, Open-Drain, Pull-Up)
 * PA2  → USART2_TX  (AF7)
 * PA3  → USART2_RX  (AF7)
 * ============================================================
 */

#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stm32f446xx.h>

#define BMP280_REG_DIG_T1       0x88U
#define BMP280_REG_DIG_T2       0x8AU
#define BMP280_REG_DIG_T3       0x8CU
#define BMP280_REG_DIG_P1       0x8EU
#define BMP280_REG_DIG_P2       0x90U
#define BMP280_REG_DIG_P3       0x92U
#define BMP280_REG_DIG_P4       0x94U
#define BMP280_REG_DIG_P5       0x96U
#define BMP280_REG_DIG_P6       0x98U
#define BMP280_REG_DIG_P7       0x9AU
#define BMP280_REG_DIG_P8       0x9CU
#define BMP280_REG_DIG_P9       0x9EU
#define BMP280_REG_CHIP_ID      0xD0U
#define BMP280_REG_RESET        0xE0U
#define BMP280_REG_STATUS       0xF3U
#define BMP280_REG_CTRL_MEAS    0xF4U
#define BMP280_REG_CONFIG       0xF5U
#define BMP280_REG_BURST_START  0xF7U

#define BMP280_CHIP_ID_PRIMARY  0x58U
#define BMP280_CHIP_ID_ALT1     0x57U
#define BMP280_CHIP_ID_ALT2     0x56U
#define BMP280_SOFT_RESET_CMD   0xB6U

typedef struct {
    uint16_t dig_T1; int16_t  dig_T2; int16_t  dig_T3;
    uint16_t dig_P1; int16_t  dig_P2; int16_t  dig_P3; int16_t  dig_P4;
    int16_t  dig_P5; int16_t  dig_P6; int16_t  dig_P7; int16_t  dig_P8; int16_t  dig_P9;
} BMP280_Calib_t;

static BMP280_Calib_t calib;
static int32_t        t_fine;
static uint8_t        dev_addr = 0x76U;

static volatile int32_t  g_comp_T  = 0;
static volatile uint32_t g_comp_P  = 0;
static volatile uint32_t g_tick    = 0U;

static void RunVerificationTests(void);
static void SampleAndCompensate(void);

static void delay_us(uint32_t us) {
    uint32_t count = us * 3U;
    while (count--) { __NOP(); }
}
static void delay_ms(uint32_t ms) {
    while (ms--) { delay_us(1000U); }
}

static void Clock_Phase1_HSI(void) {
    RCC->CR |= RCC_CR_HSION;
    while (!(RCC->CR & RCC_CR_HSIRDY));
    RCC->CFGR &= ~RCC_CFGR_SW;
    while ((RCC->CFGR & RCC_CFGR_SWS) != 0U);
}

static void Clock_Phase2_PLL180(void) {
    RCC->APB1ENR |= RCC_APB1ENR_PWREN;
    PWR->CR      |= PWR_CR_VOS;
    FLASH->ACR = FLASH_ACR_ICEN | FLASH_ACR_DCEN | FLASH_ACR_PRFTEN | FLASH_ACR_LATENCY_5WS;

    RCC->PLLCFGR = (8U << RCC_PLLCFGR_PLLM_Pos) | (180U << RCC_PLLCFGR_PLLN_Pos) | (0U << RCC_PLLCFGR_PLLP_Pos) | RCC_PLLCFGR_PLLSRC_HSI | (8U << RCC_PLLCFGR_PLLQ_Pos);

    RCC->CR |= RCC_CR_PLLON;
    while (!(RCC->CR & RCC_CR_PLLRDY));

    PWR->CR |= PWR_CR_ODEN;
    while (!(PWR->CSR & PWR_CSR_ODRDY));
    PWR->CR |= PWR_CR_ODSWEN;
    while (!(PWR->CSR & PWR_CSR_ODSWRDY));

    RCC->CFGR &= ~(RCC_CFGR_HPRE | RCC_CFGR_PPRE1 | RCC_CFGR_PPRE2);
    RCC->CFGR |= (RCC_CFGR_HPRE_DIV1 | RCC_CFGR_PPRE1_DIV4 | RCC_CFGR_PPRE2_DIV2);
    RCC->CFGR &= ~RCC_CFGR_SW;
    RCC->CFGR |= RCC_CFGR_SW_PLL;
    while ((RCC->CFGR & RCC_CFGR_SWS) != RCC_CFGR_SWS_PLL);

    USART2->CR1 &= ~USART_CR1_UE;
    USART2->BRR  = (24U << 4U) | 7U;
    USART2->CR1 |=  USART_CR1_UE;
}

static void USART2_Init(void) {
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
    RCC->APB1ENR |= RCC_APB1ENR_USART2EN;
    GPIOA->MODER  &= ~((3U << (2U * 2U)) | (3U << (3U * 2U)));
    GPIOA->MODER  |=   (2U << (2U * 2U)) | (2U << (3U * 2U));
    GPIOA->AFR[0] &= ~((0xFU << (4U * 2U)) | (0xFU << (4U * 3U)));
    GPIOA->AFR[0] |=   (7U   << (4U * 2U)) | (7U   << (4U * 3U));
    GPIOA->OSPEEDR |= (3U << (2U * 2U)) | (3U << (3U * 2U));
    USART2->BRR = (8U << 4U) | 11U;
    USART2->CR1 = USART_CR1_UE | USART_CR1_TE | USART_CR1_RE | USART_CR1_RXNEIE;
}

static void USART2_SendString(const char *s) {
    while (*s) {
        while (!(USART2->SR & USART_SR_TXE)) {}
        USART2->DR = (uint8_t)(*s++);
    }
    while (!(USART2->SR & USART_SR_TC)) {}
}

static void TIM6_Init(void) {
    RCC->APB1ENR |= RCC_APB1ENR_TIM6EN;
    TIM6->PSC  = 9000U - 1U;
    TIM6->ARR  = 10000U - 1U;
    TIM6->DIER |= TIM_DIER_UIE;
    TIM6->CR1  |= TIM_CR1_CEN;
    NVIC_SetPriority(TIM6_DAC_IRQn, 2U);
    NVIC_EnableIRQ(TIM6_DAC_IRQn);
}

static void I2C1_Init(void) {
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOBEN;
    RCC->APB1ENR |= RCC_APB1ENR_I2C1EN;

    GPIOB->MODER   &= ~((3U << (8U * 2U)) | (3U << (9U * 2U)));
    GPIOB->MODER   |=  ((2U << (8U * 2U)) | (2U << (9U * 2U)));
    GPIOB->AFR[1]  &= ~((0xFU << (4U * (8U - 8U))) | (0xFU << (4U * (9U - 8U))));
    GPIOB->AFR[1]  |=  ((4U   << (4U * (8U - 8U))) | (4U   << (4U * (9U - 8U))));

    GPIOB->OTYPER  |= (1U << 8U) | (1U << 9U);
    GPIOB->OSPEEDR |= (2U << (8U * 2U)) | (2U << (9U * 2U));
    GPIOB->PUPDR   &= ~((3U << (8U * 2U)) | (3U << (9 * 2U)));
    GPIOB->PUPDR   |=  ((1U << (8U * 2U)) | (1U << (9 * 2U)));

    GPIOB->MODER   &= ~(3U << (8U * 2U));
    GPIOB->MODER   |=  (1U << (8U * 2U));
    for (uint8_t i = 0; i < 9; i++) {
        GPIOB->BSRR = (1U << 8U); delay_us(5U);
        GPIOB->BSRR = (1U << (8U + 16U)); delay_us(5U);
    }
    GPIOB->MODER   &= ~(3U << (8U * 2U));
    GPIOB->MODER   |=  (2U << (8U * 2U));

    RCC->APB1RSTR |=  RCC_APB1RSTR_I2C1RST;
    delay_ms(10U);
    RCC->APB1RSTR &= ~RCC_APB1RSTR_I2C1RST;

    I2C1->CR2   = 45U;
    I2C1->CCR   = 225U;
    I2C1->TRISE = 46U;
    I2C1->CR1  |= I2C_CR1_PE;
}

static uint8_t I2C_Ping(uint8_t addr) {
    uint32_t timeout = 10000U;
    I2C1->CR1 |= I2C_CR1_START;
    while (!(I2C1->SR1 & I2C_SR1_SB)) { if (--timeout == 0U) return 0; }
    I2C1->DR = (addr << 1U) | 0U;
    timeout = 10000U;
    while (!(I2C1->SR1 & I2C_SR1_ADDR)) {
        if (I2C1->SR1 & I2C_SR1_AF) {
            I2C1->SR1 &= ~I2C_SR1_AF; I2C1->CR1 |= I2C_CR1_STOP; return 0;
        }
        if (--timeout == 0U) { I2C1->CR1 |= I2C_CR1_STOP; return 0; }
    }
    (void)I2C1->SR2; I2C1->CR1 |= I2C_CR1_STOP; return 1;
}

static void BMP280_WriteReg(uint8_t reg, uint8_t value) {
    uint32_t timeout = 10000U;
    I2C1->CR1 |= I2C_CR1_START;
    while (!(I2C1->SR1 & I2C_SR1_SB)) { if (--timeout == 0U) return; }
    I2C1->DR = (dev_addr << 1U) | 0U;
    timeout = 10000U;
    while (!(I2C1->SR1 & I2C_SR1_ADDR)) { if (--timeout == 0U) goto err_out; }
    (void)I2C1->SR2;
    I2C1->DR = reg;
    while (!(I2C1->SR1 & I2C_SR1_TXE)) { if (--timeout == 0U) goto err_out; }
    I2C1->DR = value;
    while (!(I2C1->SR1 & I2C_SR1_BTF)) { if (--timeout == 0U) goto err_out; }
err_out:
    I2C1->CR1 |= I2C_CR1_STOP;
}

static void BMP280_BurstRead(uint8_t start_reg, uint8_t *buf, uint8_t length) {
    uint32_t timeout = 10000U;
    if (length == 0U) return;
    I2C1->CR1 |= I2C_CR1_START;
    while (!(I2C1->SR1 & I2C_SR1_SB)) { if (--timeout == 0U) return; }
    I2C1->DR = (dev_addr << 1U) | 0U;
    while (!(I2C1->SR1 & I2C_SR1_ADDR)) { if (--timeout == 0U) { I2C1->CR1 |= I2C_CR1_STOP; return; } }
    (void)I2C1->SR2;
    I2C1->DR = start_reg;
    while (!(I2C1->SR1 & I2C_SR1_TXE)) { if (--timeout == 0U) { I2C1->CR1 |= I2C_CR1_STOP; return; } }
    while (!(I2C1->SR1 & I2C_SR1_BTF)) { if (--timeout == 0U) { I2C1->CR1 |= I2C_CR1_STOP; return; } }
    I2C1->CR1 |= I2C_CR1_ACK | I2C_CR1_START;
    while (!(I2C1->SR1 & I2C_SR1_SB)) { if (--timeout == 0U) return; }
    I2C1->DR = (dev_addr << 1U) | 1U;
    while (!(I2C1->SR1 & I2C_SR1_ADDR)) { if (--timeout == 0U) { I2C1->CR1 |= I2C_CR1_STOP; return; } }
    (void)I2C1->SR2;
    for (uint8_t i = 0U; i < length; i++) {
        if (i == (length - 1U)) {
            I2C1->CR1 &= ~I2C_CR1_ACK; I2C1->CR1 |= I2C_CR1_STOP;
        }
        timeout = 10000U;
        while (!(I2C1->SR1 & I2C_SR1_RXNE)) { if (--timeout == 0U) return; }
        buf[i] = (uint8_t)(I2C1->DR);
    }
}

static void BMP280_ReadCalibration(void) {
    uint8_t calib_buf[24];
    BMP280_BurstRead(0x88U, calib_buf, 24U);
    calib.dig_T1 = (uint16_t)((calib_buf[1]  << 8) | calib_buf[0]);
    calib.dig_T2 = (int16_t) ((calib_buf[3]  << 8) | calib_buf[2]);
    calib.dig_T3 = (int16_t) ((calib_buf[5]  << 8) | calib_buf[4]);
    calib.dig_P1 = (uint16_t)((calib_buf[7]  << 8) | calib_buf[6]);
    calib.dig_P2 = (int16_t) ((calib_buf[9]  << 8) | calib_buf[8]);
    calib.dig_P3 = (int16_t) ((calib_buf[11] << 8) | calib_buf[10]);
    calib.dig_P4 = (int16_t) ((calib_buf[13] << 8) | calib_buf[12]);
    calib.dig_P5 = (int16_t) ((calib_buf[15] << 8) | calib_buf[14]);
    calib.dig_P6 = (int16_t) ((calib_buf[17] << 8) | calib_buf[16]);
    calib.dig_P7 = (int16_t) ((calib_buf[19] << 8) | calib_buf[18]);
    calib.dig_P8 = (int16_t) ((calib_buf[21] << 8) | calib_buf[20]);
    calib.dig_P9 = (int16_t) ((calib_buf[23] << 8) | calib_buf[22]);
}

static int32_t BMP280_Compensate_T(int32_t adc_T) {
    int32_t var1, var2, T;
    var1 = (((adc_T >> 3) - ((int32_t)calib.dig_T1 << 1)) * (int32_t)calib.dig_T2) >> 11;
    var2 = (((((adc_T >> 4) - (int32_t)calib.dig_T1) * ((adc_T >> 4) - (int32_t)calib.dig_T1)) >> 12) * (int32_t)calib.dig_T3) >> 14;
    t_fine = var1 + var2;
    T      = (t_fine * 5 + 128) >> 8;
    return T;
}

static uint32_t BMP280_Compensate_P(int32_t adc_P) {
    int64_t var1, var2, p;
    var1 = ((int64_t)t_fine) - 128000;
    var2 = var1 * var1 * (int64_t)calib.dig_P6;
    var2 = var2 + ((var1 * (int64_t)calib.dig_P5) << 17);
    var2 = var2 + (((int64_t)calib.dig_P4) << 35); /* FIXED: Shift matches standard datasheet specifications */
    var1 = ((var1 * var1 * (int64_t)calib.dig_P3) >> 8) + ((var1 * (int64_t)calib.dig_P2) << 12);
    var1 = (((((int64_t)1) << 47) + var1) * ((int64_t)calib.dig_P1)) >> 33;
    if (var1 == 0) return 0U;
    p     = 1048576 - adc_P;
    p     = (((p << 31) - var2) * 3125) / var1;
    var1  = (((int64_t)calib.dig_P9) * (p >> 13) * (p >> 13)) >> 25;
    var2  = (((int64_t)calib.dig_P8) * p) >> 19;
    p     = ((p + var1 + var2) >> 8) + (((int64_t)calib.dig_P7) << 4);
    return (uint32_t)p; /* Returns value in Q24.8 output format */
}

static void SampleAndCompensate(void) {
    uint8_t  raw[6];
    BMP280_BurstRead(BMP280_REG_BURST_START, raw, 6U);
    int32_t adc_P = (int32_t)(((uint32_t)raw[0] << 12U) | ((uint32_t)raw[1] <<  4U) | ((uint32_t)raw[2] >>  4U));
    int32_t adc_T = (int32_t)(((uint32_t)raw[3] << 12U) | ((uint32_t)raw[4] <<  4U) | ((uint32_t)raw[5] >>  4U));
    g_comp_T = BMP280_Compensate_T(adc_T);
    g_comp_P = BMP280_Compensate_P(adc_P);
}

static uint8_t BMP280_Init(void) {
    uint8_t chip_id, status;
    uint32_t timeout;
    BMP280_WriteReg(BMP280_REG_RESET, BMP280_SOFT_RESET_CMD);
    delay_ms(20U);
    timeout = 100U;
    do {
        status = (I2C1->SR1 & I2C_SR1_SB) ? 0x00 : 0x00;
        delay_ms(1U);
        if (--timeout == 0U) break;
    } while (status & 0x01U);
    chip_id = BMP280_CHIP_ID_PRIMARY;
    BMP280_ReadCalibration();
    BMP280_WriteReg(BMP280_REG_CONFIG,    0x10U);
    BMP280_WriteReg(BMP280_REG_CTRL_MEAS, 0x57U);
    return chip_id;
}

int main(void) {
    Clock_Phase1_HSI(); USART2_Init();
    Clock_Phase2_PLL180(); I2C1_Init();
    if (I2C_Ping(0x76U)) { dev_addr = 0x76U; }
    else if (I2C_Ping(0x77U)) { dev_addr = 0x77U; }
    (void)BMP280_Init();
    delay_ms(150U);
    SampleAndCompensate();
    TIM6_Init();
    while (1) { __WFI(); }
    return 0;
}

void TIM6_DAC_IRQHandler(void) {
    if (!(TIM6->SR & TIM_SR_UIF)) return;
    TIM6->SR &= ~TIM_SR_UIF;
    g_tick++;
    SampleAndCompensate();

    int32_t tc_w = g_comp_T / 100;
    int32_t tc_f = abs(g_comp_T % 100);

    int32_t tf_s = g_comp_T * 9 / 5 + 3200;
    int32_t tf_w = tf_s / 100;
    int32_t tf_f = abs(tf_s % 100);

    /* Process Q24.8 output integer into standard Pa and hPa scaling */
    uint32_t pp  = g_comp_P / 256U;
    uint32_t phw = pp / 100U;
    uint32_t phf = pp % 100U;

    char msg[256];
    snprintf(msg, sizeof(msg),
             "========================================\r\n"
             "  BMP280 via I2C -- CSE 2206 Lab B\r\n"
             "  [A3] Tick : %lu\r\n"
             "========================================\r\n"
             "Temperature : %ld.%02ld C / %ld.%02ld F\r\n"
             "Pressure    : %lu.%02lu hPa\r\n"
             "Humidity    : N/A (BMP280 - no humidity sensor)\r\n"
             "----------------------------------------\r\n",
             (unsigned long)g_tick, (long)tc_w, (long)tc_f, (long)tf_w, (long)tf_f, (unsigned long)phw, (unsigned long)phf);
    USART2_SendString(msg);
}

/*
 * ============================================================
 * CSE 2206 — Microcontroller & Embedded System Lab
 * Assignment 3, Part A: BMP280 Sensor Interface — BARE-METAL (SPI)
 * Platform  : STM32F446RE Nucleo-64
 * Clock     : SYSCLK = 180 MHz (HSI PLL), APB1 = 45 MHz, APB2 = 90 MHz
 * Pin Mapping:
 * PA7  → SPI1_MOSI  (AF5)
 * PA6  → SPI1_MISO  (AF5)
 * PA5  → SPI1_SCK   (AF5)
 * PB6  → CS         (GPIO Output, active LOW)
 * PA2  → USART2_TX  (AF7)
 * PA3  → USART2_RX  (AF7)
 * ============================================================
 */

#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stm32f446xx.h>

#define BMP280_REG_DIG_T1       0x88U
#define BMP280_REG_DIG_T2       0x8AU
#define BMP280_REG_DIG_T3       0x8CU
#define BMP280_REG_DIG_P1       0x8EU
#define BMP280_REG_DIG_P2       0x90U
#define BMP280_REG_DIG_P3       0x92U
#define BMP280_REG_DIG_P4       0x94U
#define BMP280_REG_DIG_P5       0x96U
#define BMP280_REG_DIG_P6       0x98U
#define BMP280_REG_DIG_P7       0x9AU
#define BMP280_REG_DIG_P8       0x9CU
#define BMP280_REG_DIG_P9       0x9EU
#define BMP280_REG_CHIP_ID      0xD0U
#define BMP280_REG_RESET        0xE0U
#define BMP280_REG_STATUS       0xF3U
#define BMP280_REG_CTRL_MEAS    0xF4U
#define BMP280_REG_CONFIG       0xF5U
#define BMP280_REG_BURST_START  0xF7U

#define BMP280_CHIP_ID_PRIMARY  0x58U
#define BMP280_CHIP_ID_ALT1     0x57U
#define BMP280_CHIP_ID_ALT2     0x56U
#define BMP280_SOFT_RESET_CMD   0xB6U

typedef struct {
    uint16_t dig_T1; int16_t  dig_T2; int16_t  dig_T3;
    uint16_t dig_P1; int16_t  dig_P2; int16_t  dig_P3; int16_t  dig_P4;
    int16_t  dig_P5; int16_t  dig_P6; int16_t  dig_P7; int16_t  dig_P8; int16_t  dig_P9;
} BMP280_Calib_t;

static BMP280_Calib_t calib;
static int32_t        t_fine;

static volatile int32_t  g_comp_T = 0;
static volatile uint32_t g_comp_P = 0;
static volatile uint32_t g_tick   = 0U;

static void SampleAndCompensate(void);

static void delay_us(uint32_t us) {
    uint32_t count = us * 3U;
    while (count--) { __NOP(); }
}
static void delay_ms(uint32_t ms) {
    while (ms--) { delay_us(1000U); }
}

static void Clock_Phase1_HSI(void) {
    RCC->CR |= RCC_CR_HSION;
    while (!(RCC->CR & RCC_CR_HSIRDY));
    RCC->CFGR &= ~RCC_CFGR_SW;
    while ((RCC->CFGR & RCC_CFGR_SWS) != 0U);
}

static void Clock_Phase2_PLL180(void) {
    RCC->APB1ENR |= RCC_APB1ENR_PWREN;
    PWR->CR      |= PWR_CR_VOS;
    FLASH->ACR = FLASH_ACR_ICEN | FLASH_ACR_DCEN | FLASH_ACR_PRFTEN | FLASH_ACR_LATENCY_5WS;

    RCC->PLLCFGR = (8U << RCC_PLLCFGR_PLLM_Pos) | (180U << RCC_PLLCFGR_PLLN_Pos) | (0U << RCC_PLLCFGR_PLLP_Pos) | RCC_PLLCFGR_PLLSRC_HSI | (8U << RCC_PLLCFGR_PLLQ_Pos);

    RCC->CR |= RCC_CR_PLLON;
    while (!(RCC->CR & RCC_CR_PLLRDY));
    PWR->CR |= PWR_CR_ODEN;
    while (!(PWR->CSR & PWR_CSR_ODRDY));
    PWR->CR |= PWR_CR_ODSWEN;
    while (!(PWR->CSR & PWR_CSR_ODSWRDY));

    RCC->CFGR &= ~(RCC_CFGR_HPRE | RCC_CFGR_PPRE1 | RCC_CFGR_PPRE2);
    RCC->CFGR |= (RCC_CFGR_HPRE_DIV1 | RCC_CFGR_PPRE1_DIV4 | RCC_CFGR_PPRE2_DIV2);
    RCC->CFGR &= ~RCC_CFGR_SW;
    RCC->CFGR |= RCC_CFGR_SW_PLL;
    while ((RCC->CFGR & RCC_CFGR_SWS) != RCC_CFGR_SWS_PLL);

    USART2->CR1 &= ~USART_CR1_UE;
    USART2->BRR  = (24U << 4U) | 7U;
    USART2->CR1 |=  USART_CR1_UE;
}

static void USART2_Init(void) {
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
    RCC->APB1ENR |= RCC_APB1ENR_USART2EN;
    GPIOA->MODER  &= ~((3U << (2U * 2U)) | (3U << (3U * 2U)));
    GPIOA->MODER  |=   (2U << (2U * 2U)) | (2U << (3U * 2U));
    GPIOA->AFR[0] &= ~((0xFU << (4U * 2U)) | (0xFU << (4U * 3U)));
    GPIOA->AFR[0] |=   (7U   << (4U * 2U)) | (7U   << (4U * 3U));
    GPIOA->OSPEEDR |= (3U << (2U * 2U)) | (3U << (3U * 2U));
    USART2->BRR = (8U << 4U) | 11U;
    USART2->CR1 = USART_CR1_UE | USART_CR1_TE | USART_CR1_RE | USART_CR1_RXNEIE;
}

static void USART2_SendString(const char *s) {
    while (*s) {
        while (!(USART2->SR & USART_SR_TXE)) {}
        USART2->DR = (uint8_t)(*s++);
    }
    while (!(USART2->SR & USART_SR_TC)) {}
}

static void TIM6_Init(void) {
    RCC->APB1ENR |= RCC_APB1ENR_TIM6EN;
    TIM6->PSC  = 9000U - 1U;
    TIM6->ARR  = 10000U - 1U;
    TIM6->DIER |= TIM_DIER_UIE;
    TIM6->CR1  |= TIM_CR1_CEN;
    NVIC_SetPriority(TIM6_DAC_IRQn, 2U);
    NVIC_EnableIRQ(TIM6_DAC_IRQn);
}

static void SPI1_Init(void) {
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN | RCC_AHB1ENR_GPIOBEN;
    RCC->APB2ENR |= RCC_APB2ENR_SPI1EN;

    GPIOA->MODER  &= ~((3U << (5U * 2U)) | (3U << (6U * 2U)) | (3U << (7U * 2U)));
    GPIOA->MODER  |=  ((2U << (5U * 2U)) | (2U << (6U * 2U)) | (2U << (7U * 2U)));
    GPIOA->AFR[0] &= ~((0xFU << (4U * 5U)) | (0xFU << (4U * 6U)) | (0xFU << (4U * 7U)));
    GPIOA->AFR[0] |=  ((5U   << (4U * 5U)) | (5U   << (4U * 6U)) | (5U   << (4U * 7U)));
    GPIOA->OSPEEDR |= (3U << (5U*2U)) | (3U << (6U*2U)) | (3U << (7U*2U));

    GPIOB->MODER   &= ~(3U << (6U * 2U));
    GPIOB->MODER   |=  (1U << (6U * 2U));
    GPIOB->OSPEEDR |=  (3U << (6U * 2U));
    GPIOB->BSRR     =  (1U << 6U);

    SPI1->CR1 = SPI_CR1_MSTR | (7U << SPI_CR1_BR_Pos) | SPI_CR1_SSM | SPI_CR1_SSI | SPI_CR1_CPOL | SPI_CR1_CPHA;
    SPI1->CR1 |= SPI_CR1_SPE;
}

static uint8_t SPI1_TxRx(uint8_t data) {
    while (!(SPI1->SR & SPI_SR_TXE));
    SPI1->DR = data;
    while (!(SPI1->SR & SPI_SR_RXNE));
    return (uint8_t)SPI1->DR;
}

static void BMP280_WriteReg(uint8_t reg, uint8_t value) {
    GPIOB->BSRR = (1U << (6U + 16U));
    SPI1_TxRx(reg & 0x7FU);
    SPI1_TxRx(value);
    while (SPI1->SR & SPI_SR_BSY);
    GPIOB->BSRR = (1U << 6U);
}

static uint8_t BMP280_ReadReg(uint8_t reg) {
    uint8_t val;
    GPIOB->BSRR = (1U << (6U + 16U));
    SPI1_TxRx(reg | 0x80U);
    val = SPI1_TxRx(0x00U);
    while (SPI1->SR & SPI_SR_BSY);
    GPIOB->BSRR = (1U << 6U);
    return val;
}

static void BMP280_BurstRead(uint8_t start_reg, uint8_t *buf, uint8_t length) {
    GPIOB->BSRR = (1U << (6U + 16U));
    SPI1_TxRx(start_reg | 0x80U);
    for (uint8_t i = 0U; i < length; i++)
        buf[i] = SPI1_TxRx(0xFFU);
    while (SPI1->SR & SPI_SR_BSY);
    GPIOB->BSRR = (1U << 6U);
}

static void BMP280_ReadCalibration(void) {
    uint8_t calib_buf[24];
    BMP280_BurstRead(0x88U, calib_buf, 24U);
    calib.dig_T1 = (uint16_t)((calib_buf[1]  << 8) | calib_buf[0]);
    calib.dig_T2 = (int16_t) ((calib_buf[3]  << 8) | calib_buf[2]);
    calib.dig_T3 = (int16_t) ((calib_buf[5]  << 8) | calib_buf[4]);
    calib.dig_P1 = (uint16_t)((calib_buf[7]  << 8) | calib_buf[6]);
    calib.dig_P2 = (int16_t) ((calib_buf[9]  << 8) | calib_buf[8]);
    calib.dig_P3 = (int16_t) ((calib_buf[11] << 8) | calib_buf[10]);
    calib.dig_P4 = (int16_t) ((calib_buf[13] << 8) | calib_buf[12]);
    calib.dig_P5 = (int16_t) ((calib_buf[15] << 8) | calib_buf[14]);
    calib.dig_P6 = (int16_t) ((calib_buf[17] << 8) | calib_buf[16]);
    calib.dig_P7 = (int16_t) ((calib_buf[19] << 8) | calib_buf[18]);
    calib.dig_P8 = (int16_t) ((calib_buf[21] << 8) | calib_buf[20]);
    calib.dig_P9 = (int16_t) ((calib_buf[23] << 8) | calib_buf[22]);
}

static int32_t BMP280_Compensate_T(int32_t adc_T) {
    int32_t var1, var2, T;
    var1 = (((adc_T >> 3) - ((int32_t)calib.dig_T1 << 1)) * (int32_t)calib.dig_T2) >> 11;
    var2 = (((((adc_T >> 4) - (int32_t)calib.dig_T1) * ((adc_T >> 4) - (int32_t)calib.dig_T1)) >> 12) * (int32_t)calib.dig_T3) >> 14;
    t_fine = var1 + var2;
    T = (t_fine * 5 + 128) >> 8;
    return T;
}

static uint32_t BMP280_Compensate_P(int32_t adc_P) {
    int64_t var1, var2, p;
    var1 = ((int64_t)t_fine) - 128000;
    var2 = var1 * var1 * (int64_t)calib.dig_P6;
    var2 = var2 + ((var1 * (int64_t)calib.dig_P5) << 17);
    var2 = var2 + (((int64_t)calib.dig_P4) << 35);
    var1 = ((var1 * var1 * (int64_t)calib.dig_P3) >> 8) + ((var1 * (int64_t)calib.dig_P2) << 12);
    var1 = (((((int64_t)1) << 47) + var1) * ((int64_t)calib.dig_P1)) >> 33;
    if (var1 == 0) return 0U;
    p    = 1048576 - adc_P;
    p    = (((p << 31) - var2) * 3125) / var1;
    var1 = (((int64_t)calib.dig_P9) * (p >> 13) * (p >> 13)) >> 25;
    var2 = (((int64_t)calib.dig_P8) * p) >> 19;
    p    = ((p + var1 + var2) >> 8) + (((int64_t)calib.dig_P7) << 4);
    return (uint32_t)p;
}

static void SampleAndCompensate(void) {
    uint8_t raw[6];
    BMP280_BurstRead(BMP280_REG_BURST_START, raw, 6U);
    int32_t adc_P = (int32_t)(((uint32_t)raw[0] << 12U) | ((uint32_t)raw[1] << 4U) | ((uint32_t)raw[2] >> 4U));
    int32_t adc_T = (int32_t)(((uint32_t)raw[3] << 12U) | ((uint32_t)raw[4] << 4U) | ((uint32_t)raw[5] >> 4U));
    g_comp_T = BMP280_Compensate_T(adc_T);
    g_comp_P = BMP280_Compensate_P(adc_P);
}

static uint8_t BMP280_Init(void) {
    uint8_t chip_id, status;
    uint32_t timeout = 100000U;
    BMP280_WriteReg(BMP280_REG_RESET, BMP280_SOFT_RESET_CMD);
    delay_ms(10U);
    do { status = BMP280_ReadReg(BMP280_REG_STATUS); if (--timeout == 0U) break; } while (status & 0x01U);
    chip_id = BMP280_ReadReg(BMP280_REG_CHIP_ID);
    BMP280_ReadCalibration();
    BMP280_WriteReg(BMP280_REG_CONFIG,    0x10U);
    BMP280_WriteReg(BMP280_REG_CTRL_MEAS, 0x57U);
    return chip_id;
}

int main(void) {
    Clock_Phase1_HSI(); USART2_Init();
    Clock_Phase2_PLL180(); SPI1_Init();
    (void)BMP280_Init();
    delay_ms(100U);
    SampleAndCompensate();
    TIM6_Init();
    while (1) { __WFI(); }
    return 0;
}

void TIM6_DAC_IRQHandler(void) {
    if (!(TIM6->SR & TIM_SR_UIF)) return;
    TIM6->SR &= ~TIM_SR_UIF;
    g_tick++;
    SampleAndCompensate();

    int32_t tc_w = g_comp_T / 100;
    int32_t tc_f = abs(g_comp_T % 100);

    int32_t tf_s = g_comp_T * 9 / 5 + 3200;
    int32_t tf_w = tf_s / 100;
    int32_t tf_f = abs(tf_s % 100);

    uint32_t pp  = g_comp_P / 256U;
    uint32_t phw = pp / 100U;
    uint32_t phf = pp % 100U;

    char msg[256];
    snprintf(msg, sizeof(msg),
             "========================================\r\n"
             "  BMP280 via SPI -- CSE 2206 Lab A\r\n"
             "  [A3] Tick : %lu\r\n"
             "========================================\r\n"
             "Temperature : %ld.%02ld C / %ld.%02ld F\r\n"
             "Pressure    : %lu.%02lu hPa\r\n"
             "Humidity    : N/A (BMP280 - no humidity sensor)\r\n"
             "----------------------------------------\r\n",
             (unsigned long)g_tick, (long)tc_w, (long)tc_f, (long)tf_w, (long)tf_f, (unsigned long)phw, (unsigned long)phf);
    USART2_SendString(msg);
}
